to initialize namespace when new file is created in php run:
composer dump-autoload -o

to download phpmailer/phpmailer
composer require phpmailer/phpmailer