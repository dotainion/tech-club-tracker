<?php

namespace src\infrastructure;

use tools\infrastructure\SearchRequest as ToolsSearchRequest;

class SearchRequest extends ToolsSearchRequest{
    
    public function __construct(){
        parent::__construct();
    }
}
